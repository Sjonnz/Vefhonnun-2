1. Ég ætla að klára helstu atriðin fyrst aður að ég færi það út um allt og í önnur html.
2. Ég ætla að reyna að gera allt eins "smooth" og hætt er.
3. Ég ætla að taka góðan tíma í að vinna með sprettigluggana og animations. 