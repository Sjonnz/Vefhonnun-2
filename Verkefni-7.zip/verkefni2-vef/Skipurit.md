Forsíða(index)
Um okkur
Miðar
Dagskrá
Spjallbox

1. Á forsíðu ælta það að vera stutt kynning um hljómsveitina(sem ég ætla að velja) sem ætla að gigga og verður stutt kynning um það
2. Dagskráin er í töflu 
3. Skráningarsíðan verður í pop-up sem maður mun ýta á annar hvort í forsíðu, eða í Miðar.
4. Spjallboxið er pop-up sem er fyrir neðan skjáin allan tíman.
5. Um okkur verður um hljómsveitina. 